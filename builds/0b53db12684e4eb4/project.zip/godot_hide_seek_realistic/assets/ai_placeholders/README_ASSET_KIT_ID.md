# Asset 3D Realistis Procedural

Asset di project ini sudah dipasangkan langsung lewat `scripts/HouseBuilder.gd` supaya ringan dan aman dibuka di Godot 4 tanpa download eksternal.

Yang ditambahkan:
- Mansion 3D lebih realistis: ceiling, trim tembok, pilar kayu, jendela kaca, frame, dan lampu hangat.
- Furniture 3D: sofa detail, meja kaca, meja makan + kursi, kasur + bantal + selimut, lemari, kitchen set, bathtub, toilet, bookshelf, piano, tangga, crate, tanaman, basement shelf, dan pipe.
- Material realistis: wood, marble, metal, glass transparan, fabric, carpet, dark basement.
- Hide spot tetap ada: sofa, meja, under bed, wardrobe, storage, bookshelf, basement box.

Catatan:
- Ini bukan asset dari internet, jadi tidak ada lisensi eksternal.
- Semua asset dibuat procedural di Godot agar build tidak berat dan tidak butuh file .glb besar.
