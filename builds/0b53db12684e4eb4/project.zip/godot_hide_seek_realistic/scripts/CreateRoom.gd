extends Control

@onready var name_input: LineEdit = $Center/Panel/VBox/RoomNameInput
@onready var port_input: LineEdit = $Center/Panel/VBox/PortInput
@onready var max_slider: HSlider = $Center/Panel/VBox/MaxRow/MaxSlider
@onready var max_value: Label = $Center/Panel/VBox/MaxRow/MaxValue
@onready var mode_option: OptionButton = $Center/Panel/VBox/ModeRow/ModeOption
@onready var hide_label: Label = $Center/Panel/VBox/TimingRow/HideLabel
@onready var seek_label: Label = $Center/Panel/VBox/TimingRow/SeekLabel
@onready var status_label: Label = $Center/Panel/VBox/Status

func _ready() -> void:
	name_input.text = "%s Mansion" % NetworkManager.get_local_name()
	port_input.text = str(NetworkManager.DEFAULT_PORT)
	mode_option.add_item("Classic")
	mode_option.add_item("Fast")
	mode_option.add_item("Long")
	mode_option.select(0)
	max_slider.min_value = 2
	max_slider.max_value = NetworkManager.MAX_PLAYERS_CAP
	max_slider.step = 1
	max_slider.value = NetworkManager.max_players
	max_value.text = "%d pemain" % int(max_slider.value)
	_apply_mode_to_labels("Classic")
	max_slider.value_changed.connect(_on_max_changed)
	mode_option.item_selected.connect(_on_mode_changed)
	$Center/Panel/VBox/HBox/CreateButton.pressed.connect(_create)
	$Center/Panel/VBox/HBox/BackButton.pressed.connect(_back)
	NetworkManager.connection_status.connect(_on_status)

func _on_max_changed(value: float) -> void:
	max_value.text = "%d pemain" % int(value)

func _on_mode_changed(idx: int) -> void:
	var mode := mode_option.get_item_text(idx)
	_apply_mode_to_labels(mode)

func _apply_mode_to_labels(mode: String) -> void:
	var hide := 35
	var seek := 240
	match mode:
		"Fast":
			hide = 20
			seek = 120
		"Long":
			hide = 60
			seek = 360
		_:
			hide = 35
			seek = 240
	hide_label.text = "Sembunyi: %ds" % hide
	seek_label.text = "Pencarian: %ds" % seek

func _create() -> void:
	NetworkManager.room_name = name_input.text.strip_edges() if name_input.text.strip_edges() != "" else "Mansion Room"
	NetworkManager.max_players = int(max_slider.value)
	NetworkManager.apply_mode(mode_option.get_item_text(mode_option.selected))
	var port: int = int(port_input.text) if port_input.text.is_valid_int() else NetworkManager.DEFAULT_PORT
	status_label.text = "Membuat room..."
	if NetworkManager.host_game(port):
		get_tree().change_scene_to_file("res://scenes/Lobby.tscn")

func _back() -> void:
	get_tree().change_scene_to_file("res://scenes/MainMenu.tscn")

func _on_status(message: String) -> void:
	status_label.text = message
