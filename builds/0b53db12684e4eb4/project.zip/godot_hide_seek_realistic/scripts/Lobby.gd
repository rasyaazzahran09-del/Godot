extends Control

@onready var room_info_label: Label = $Center/Panel/VBox/RoomInfo
@onready var mode_label: Label = $Center/Panel/VBox/ModeInfo
@onready var players_list: ItemList = $Center/Panel/VBox/Players
@onready var status_label: Label = $Center/Panel/VBox/Status
@onready var start_button: Button = $Center/Panel/VBox/HBox/StartButton

func _ready() -> void:
	start_button.pressed.connect(func(): NetworkManager.start_game())
	$Center/Panel/VBox/HBox/BackButton.pressed.connect(_back)
	$Center/Panel/VBox/HBox/CopyButton.pressed.connect(_copy_share)
	NetworkManager.players_changed.connect(_update_players)
	NetworkManager.connection_status.connect(_set_status)
	NetworkManager.room_settings_changed.connect(_refresh_room_info)
	_update_players(NetworkManager.players)
	_refresh_room_info()
	start_button.disabled = not NetworkManager.is_host

func _back() -> void:
	NetworkManager.leave_room()
	get_tree().change_scene_to_file("res://scenes/MainMenu.tscn")

func _copy_share() -> void:
	var port_string := str(NetworkManager.DEFAULT_PORT)
	var share := "Room: %s | Code: %s | Port: %s" % [NetworkManager.room_name, NetworkManager.room_code, port_string]
	DisplayServer.clipboard_set(share)
	status_label.text = "Info room tersalin ke clipboard."

func _refresh_room_info() -> void:
	var code: String = NetworkManager.room_code if NetworkManager.room_code != "" else "-"
	room_info_label.text = "%s · Code %s" % [NetworkManager.room_name, code]
	mode_label.text = "Mode %s · Sembunyi %ds · Cari %ds · Max %d" % [
		NetworkManager.game_mode,
		NetworkManager.hide_seconds,
		NetworkManager.seek_seconds,
		NetworkManager.max_players,
	]

func _update_players(players: Dictionary) -> void:
	players_list.clear()
	for id in players.keys():
		var p: Dictionary = players[id]
		var line := "%s  •  %s" % [p.get("name", str(id)), p.get("role", "Hider")]
		players_list.add_item(line)
	start_button.disabled = not NetworkManager.is_host

func _set_status(message: String) -> void:
	status_label.text = message
