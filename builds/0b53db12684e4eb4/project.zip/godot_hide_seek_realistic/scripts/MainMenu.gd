extends Control

@onready var settings_panel: PanelContainer = $SettingsPanel
@onready var welcome_label: Label = $TopBar/HBox/Welcome
@onready var name_edit: LineEdit = $SettingsPanel/VBox/NameInput

func _ready() -> void:
	welcome_label.text = "Halo, %s" % NetworkManager.get_local_name()
	name_edit.text = NetworkManager.player_name
	$Center/Panel/VBox/PlayButton.pressed.connect(_quick_play)
	$Center/Panel/VBox/CreateRoomButton.pressed.connect(_create_room)
	$Center/Panel/VBox/JoinRoomButton.pressed.connect(_join_room)
	$Center/Panel/VBox/SettingsButton.pressed.connect(_open_settings)
	$Center/Panel/VBox/ExitButton.pressed.connect(func(): get_tree().quit())
	$TopBar/HBox/LogoutButton.pressed.connect(_logout)
	$SettingsPanel/VBox/HBox/CloseButton.pressed.connect(_close_settings)
	$SettingsPanel/VBox/HBox/SaveButton.pressed.connect(_save_settings)

func _quick_play() -> void:
	NetworkManager.room_name = "%s Mansion" % NetworkManager.get_local_name()
	if NetworkManager.host_game(NetworkManager.DEFAULT_PORT):
		get_tree().change_scene_to_file("res://scenes/Lobby.tscn")

func _create_room() -> void:
	get_tree().change_scene_to_file("res://scenes/CreateRoom.tscn")

func _join_room() -> void:
	get_tree().change_scene_to_file("res://scenes/JoinRoom.tscn")

func _logout() -> void:
	NetworkManager.player_name = ""
	get_tree().change_scene_to_file("res://scenes/Login.tscn")

func _open_settings() -> void:
	settings_panel.visible = true
	name_edit.text = NetworkManager.player_name
	name_edit.grab_focus()

func _close_settings() -> void:
	settings_panel.visible = false

func _save_settings() -> void:
	var n := name_edit.text.strip_edges()
	if n != "":
		NetworkManager.player_name = n.left(18)
		welcome_label.text = "Halo, %s" % NetworkManager.get_local_name()
	settings_panel.visible = false
