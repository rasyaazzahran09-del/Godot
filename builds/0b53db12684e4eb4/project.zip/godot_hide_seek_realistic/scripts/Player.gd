extends CharacterBody3D

signal caught(player_id: int)

@export var walk_speed := 4.0
@export var run_speed := 7.0
@export var crouch_speed := 2.0
@export var jump_velocity := 5.2
@export var mouse_sensitivity := 0.0025

var player_id := 1
var role := "Hider"
var is_caught := false
var input_vector := Vector2.ZERO
var mobile_jump := false
var mobile_sprint := false
var mobile_crouch := false
var mobile_interact := false
var _gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")
var _camera_yaw := 0.0
var _camera_pitch := -0.18
var _footstep_timer := 0.0

@onready var camera_pivot: Node3D = $CameraPivot
@onready var camera: Camera3D = $CameraPivot/Camera3D
@onready var ray: RayCast3D = $CameraPivot/InteractRay
@onready var name_label: Label3D = $NameLabel
@onready var footstep_player: AudioStreamPlayer3D = $FootstepPlayer
@onready var caught_player: AudioStreamPlayer3D = $CaughtPlayer

func _ready() -> void:
	set_multiplayer_authority(player_id)
	name = "Player_%s" % player_id
	name_label.text = "%s (%s)" % [NetworkManager.players.get(player_id, {}).get("name", "Player"), role]
	if is_multiplayer_authority():
		camera.current = true
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _unhandled_input(event: InputEvent) -> void:
	if not is_multiplayer_authority() or is_caught: return
	if event is InputEventMouseMotion:
		_camera_yaw -= event.relative.x * mouse_sensitivity
		_camera_pitch = clamp(_camera_pitch - event.relative.y * mouse_sensitivity, -0.85, 0.45)
	if event.is_action_pressed("interact"):
		_try_interact()

func _physics_process(delta: float) -> void:
	if not is_multiplayer_authority():
		return
	if is_caught:
		velocity.x = move_toward(velocity.x, 0, delta * 10)
		velocity.z = move_toward(velocity.z, 0, delta * 10)
		move_and_slide()
		return
	_update_camera()
	var input_dir := _get_input_dir()
	var basis := Basis(Vector3.UP, _camera_yaw)
	var direction := (basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
	var sprinting := Input.is_action_pressed("sprint") or mobile_sprint
	var crouching := Input.is_action_pressed("crouch") or mobile_crouch
	var target_speed := crouch_speed if crouching else (run_speed if sprinting else walk_speed)
	velocity.x = lerp(velocity.x, direction.x * target_speed, 10.0 * delta)
	velocity.z = lerp(velocity.z, direction.z * target_speed, 10.0 * delta)
	if not is_on_floor():
		velocity.y -= _gravity * delta
	elif Input.is_action_just_pressed("jump") or mobile_jump:
		velocity.y = jump_velocity
		mobile_jump = false
	else:
		velocity.y = -0.05
	move_and_slide()
	_handle_footsteps(delta, direction.length(), sprinting)
	if mobile_interact:
		mobile_interact = false
		_try_interact()
	_rpc_transform.rpc(global_position, rotation.y, _camera_yaw, _camera_pitch)

func _get_input_dir() -> Vector2:
	var key_dir := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	return input_vector if input_vector.length() > 0.05 else key_dir

func _update_camera() -> void:
	rotation.y = _camera_yaw
	camera_pivot.rotation.x = _camera_pitch

func _handle_footsteps(delta: float, moving_amount: float, sprinting: bool) -> void:
	if moving_amount < 0.1 or not is_on_floor():
		return
	_footstep_timer -= delta
	var interval := 0.28 if sprinting else 0.42
	if _footstep_timer <= 0.0:
		_footstep_timer = interval
		if footstep_player.stream:
			footstep_player.pitch_scale = randf_range(0.92, 1.08)
			footstep_player.play()

func _try_interact() -> void:
	if role != "Seeker": return
	ray.force_raycast_update()
	if ray.is_colliding():
		var target := ray.get_collider()
		if target and target.has_method("request_caught"):
			target.request_caught.rpc_id(1, player_id)

@rpc("any_peer", "reliable")
func request_caught(seeker_id: int) -> void:
	if not multiplayer.is_server(): return
	if role == "Hider" and not is_caught:
		mark_caught.rpc()
		caught.emit(player_id)

@rpc("any_peer", "reliable", "call_local")
func mark_caught() -> void:
	is_caught = true
	name_label.text = "%s - CAUGHT" % name_label.text
	if caught_player.stream:
		caught_player.play()

@rpc("any_peer", "unreliable")
func _rpc_transform(pos: Vector3, rot_y: float, yaw: float, pitch: float) -> void:
	if is_multiplayer_authority(): return
	global_position = global_position.lerp(pos, 0.35)
	rotation.y = lerp_angle(rotation.y, rot_y, 0.35)
	camera_pivot.rotation.x = lerp_angle(camera_pivot.rotation.x, pitch, 0.35)
