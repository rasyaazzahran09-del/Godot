extends Node

signal players_changed(players: Dictionary)
signal connection_status(message: String)
signal game_requested_start
signal room_settings_changed

const DEFAULT_PORT := 7777
const MAX_PLAYERS_CAP := 8

var peer: ENetMultiplayerPeer
var players: Dictionary = {}
var room_code: String = ""
var room_name: String = "Mansion Room"
var max_players: int = 6
var game_mode: String = "Classic"
var hide_seconds: int = 35
var seek_seconds: int = 240
var player_name: String = ""
var is_host := false

func _ready() -> void:
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected_to_server)
	multiplayer.connection_failed.connect(_on_connection_failed)
	multiplayer.server_disconnected.connect(_on_server_disconnected)

func get_local_name() -> String:
	return player_name if player_name != "" else "Player"

func apply_mode(mode: String) -> void:
	game_mode = mode
	match mode:
		"Fast":
			hide_seconds = 20
			seek_seconds = 120
		"Long":
			hide_seconds = 60
			seek_seconds = 360
		_:
			hide_seconds = 35
			seek_seconds = 240
	room_settings_changed.emit()

func host_game(port: int = DEFAULT_PORT) -> bool:
	_cleanup_peer()
	peer = ENetMultiplayerPeer.new()
	var capped: int = clamp(max_players, 2, MAX_PLAYERS_CAP)
	var err := peer.create_server(port, capped)
	if err != OK:
		connection_status.emit("Gagal host room. Port mungkin sudah dipakai.")
		return false
	multiplayer.multiplayer_peer = peer
	is_host = true
	room_code = str(randi_range(100000, 999999))
	players.clear()
	players[multiplayer.get_unique_id()] = {
		"name": get_local_name(),
		"role": "Seeker",
		"caught": false,
	}
	connection_status.emit("Room aktif: %s | Code: %s | Port: %d" % [room_name, room_code, port])
	players_changed.emit(players)
	return true

func join_game(ip: String, port: int = DEFAULT_PORT) -> bool:
	_cleanup_peer()
	if ip.strip_edges().is_empty():
		connection_status.emit("IP host tidak boleh kosong.")
		return false
	peer = ENetMultiplayerPeer.new()
	var err := peer.create_client(ip, port)
	if err != OK:
		connection_status.emit("Gagal join room. Cek IP / port.")
		return false
	multiplayer.multiplayer_peer = peer
	is_host = false
	connection_status.emit("Menghubungkan ke host %s:%d..." % [ip, port])
	return true

func leave_room() -> void:
	_cleanup_peer()
	players.clear()
	is_host = false
	room_code = ""
	players_changed.emit(players)

func start_game() -> void:
	if not multiplayer.is_server():
		connection_status.emit("Hanya host yang bisa mulai game.")
		return
	if players.size() < 1:
		connection_status.emit("Minimal 1 pemain. Untuk mabar gunakan 2+ pemain.")
		return
	_assign_roles()
	var settings := {
		"hide_seconds": hide_seconds,
		"seek_seconds": seek_seconds,
		"mode": game_mode,
		"room_name": room_name,
	}
	rpc("_client_start_game", players, settings)
	_client_start_game(players, settings)

func _assign_roles() -> void:
	var ids := players.keys()
	ids.sort()
	for i in ids.size():
		var id = ids[i]
		players[id]["role"] = "Seeker" if i == 0 else "Hider"
		players[id]["caught"] = false
	players_changed.emit(players)

@rpc("any_peer", "reliable")
func register_player(p_name: String) -> void:
	if not multiplayer.is_server(): return
	var id := multiplayer.get_remote_sender_id()
	players[id] = {"name": p_name.left(18), "role": "Hider", "caught": false}
	rpc("sync_players", players)
	sync_players(players)

@rpc("authority", "reliable")
func sync_players(new_players: Dictionary) -> void:
	players = new_players
	players_changed.emit(players)

@rpc("authority", "reliable")
func _client_start_game(new_players: Dictionary, settings: Dictionary) -> void:
	players = new_players
	hide_seconds = int(settings.get("hide_seconds", hide_seconds))
	seek_seconds = int(settings.get("seek_seconds", seek_seconds))
	game_mode = str(settings.get("mode", game_mode))
	room_name = str(settings.get("room_name", room_name))
	get_tree().change_scene_to_file("res://scenes/GameWorld.tscn")

func _on_peer_connected(id: int) -> void:
	if multiplayer.is_server():
		connection_status.emit("Player tersambung: %s" % id)

func _on_peer_disconnected(id: int) -> void:
	if multiplayer.is_server():
		players.erase(id)
		rpc("sync_players", players)
		sync_players(players)
	connection_status.emit("Player disconnect: %s" % id)

func _on_connected_to_server() -> void:
	connection_status.emit("Berhasil join room.")
	rpc_id(1, "register_player", get_local_name())

func _on_connection_failed() -> void:
	connection_status.emit("Koneksi gagal. Room/IP tidak ditemukan.")
	_cleanup_peer()

func _on_server_disconnected() -> void:
	connection_status.emit("Host keluar / koneksi putus. Kembali ke lobby.")
	_cleanup_peer()
	get_tree().call_deferred("change_scene_to_file", "res://scenes/Lobby.tscn")

func _cleanup_peer() -> void:
	if multiplayer.multiplayer_peer:
		multiplayer.multiplayer_peer.close()
	multiplayer.multiplayer_peer = null
	peer = null
