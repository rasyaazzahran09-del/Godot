extends Control

@onready var ip_input: LineEdit = $Center/Panel/VBox/IpInput
@onready var port_input: LineEdit = $Center/Panel/VBox/PortInput
@onready var status_label: Label = $Center/Panel/VBox/Status

func _ready() -> void:
	ip_input.text = "127.0.0.1"
	port_input.text = str(NetworkManager.DEFAULT_PORT)
	$Center/Panel/VBox/HBox/JoinButton.pressed.connect(_join)
	$Center/Panel/VBox/HBox/BackButton.pressed.connect(_back)
	NetworkManager.connection_status.connect(_on_status)
	NetworkManager.players_changed.connect(_on_players)

func _join() -> void:
	var port: int = int(port_input.text) if port_input.text.is_valid_int() else NetworkManager.DEFAULT_PORT
	status_label.text = "Mencoba join %s:%d..." % [ip_input.text.strip_edges(), port]
	if NetworkManager.join_game(ip_input.text.strip_edges(), port):
		get_tree().change_scene_to_file("res://scenes/Lobby.tscn")

func _back() -> void:
	get_tree().change_scene_to_file("res://scenes/MainMenu.tscn")

func _on_status(message: String) -> void:
	if is_inside_tree() and status_label:
		status_label.text = message

func _on_players(_p: Dictionary) -> void:
	pass
