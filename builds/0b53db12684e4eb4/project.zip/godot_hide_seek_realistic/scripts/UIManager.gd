extends CanvasLayer

@onready var timer_label: Label = $Root/TopBar/HBox/TimerLabel
@onready var role_label: Label = $Root/TopBar/HBox/RoleLabel
@onready var status_label: Label = $Root/TopBar/HBox/StatusLabel
@onready var room_label: Label = $Root/TopBar/HBox/RoomLabel
@onready var joystick: Control = $Root/Joystick
@onready var end_panel: PanelContainer = $Root/EndPanel
@onready var end_text: Label = $Root/EndPanel/VBox/EndText

func _ready() -> void:
	joystick.moved.connect(_on_joystick_moved)
	$Root/JumpButton.button_down.connect(_set_jump)
	$Root/SprintButton.button_down.connect(_set_sprint.bind(true))
	$Root/SprintButton.button_up.connect(_set_sprint.bind(false))
	$Root/CrouchButton.button_down.connect(_set_crouch.bind(true))
	$Root/CrouchButton.button_up.connect(_set_crouch.bind(false))
	$Root/InteractButton.pressed.connect(_set_interact)
	var mobile := OS.has_feature("mobile") or DisplayServer.is_touchscreen_available()
	$Root/JumpButton.visible = mobile
	$Root/SprintButton.visible = mobile
	$Root/CrouchButton.visible = mobile
	$Root/InteractButton.visible = mobile
	$Root/EndPanel/VBox/HBox/LobbyButton.pressed.connect(_back_to_lobby)
	$Root/EndPanel/VBox/HBox/MenuButton.pressed.connect(_back_to_menu)
	room_label.text = "Room: %s" % NetworkManager.room_name

func set_match_info(role: String, state: String, seconds: int) -> void:
	role_label.text = "Role: %s" % role
	status_label.text = "Status: %s" % state.capitalize()
	timer_label.text = "Timer: %02d:%02d" % [max(0, seconds) / 60, max(0, seconds) % 60]

func show_result(message: String) -> void:
	end_panel.visible = true
	end_text.text = message

func _local_player():
	var root := get_tree().current_scene
	if not root: return null
	var node := root.get_node_or_null("Players/Player_%s" % multiplayer.get_unique_id())
	return node

func _on_joystick_moved(v: Vector2) -> void:
	var p = _local_player()
	if p: p.input_vector = v

func _set_jump() -> void:
	var p = _local_player()
	if p: p.mobile_jump = true

func _set_sprint(v: bool) -> void:
	var p = _local_player()
	if p: p.mobile_sprint = v

func _set_crouch(v: bool) -> void:
	var p = _local_player()
	if p: p.mobile_crouch = v

func _set_interact() -> void:
	var p = _local_player()
	if p: p.mobile_interact = true

func _back_to_lobby() -> void:
	NetworkManager.leave_room()
	get_tree().change_scene_to_file("res://scenes/Lobby.tscn")

func _back_to_menu() -> void:
	NetworkManager.leave_room()
	get_tree().change_scene_to_file("res://scenes/MainMenu.tscn")
