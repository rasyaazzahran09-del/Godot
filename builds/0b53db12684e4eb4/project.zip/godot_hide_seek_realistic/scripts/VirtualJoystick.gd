extends Control

signal moved(value: Vector2)

var value := Vector2.ZERO
var dragging := false
var active_touch := -1
var radius := 70.0

func _ready() -> void:
	visible = OS.has_feature("mobile") or DisplayServer.is_touchscreen_available()
	custom_minimum_size = Vector2(radius * 2.0, radius * 2.0)

func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed and _inside(event.position):
			dragging = true
			active_touch = event.index
			_update_value(event.position)
		elif event.index == active_touch:
			_reset()
	elif event is InputEventScreenDrag and event.index == active_touch:
		_update_value(event.position)
	elif event is InputEventMouseButton:
		if event.pressed and _inside(event.position):
			dragging = true
			_update_value(event.position)
		elif not event.pressed:
			_reset()
	elif event is InputEventMouseMotion and dragging:
		_update_value(event.position)

func _draw() -> void:
	var center := size * 0.5
	draw_circle(center, radius, Color(1,1,1,0.12))
	draw_arc(center, radius, 0, TAU, 64, Color(1,1,1,0.5), 3)
	draw_circle(center + value * radius, 32, Color(0.9,0.75,0.35,0.85))

func _inside(pos: Vector2) -> bool:
	return pos.distance_to(size * 0.5) <= radius * 1.35

func _update_value(pos: Vector2) -> void:
	value = ((pos - size * 0.5) / radius).limit_length(1.0)
	moved.emit(Vector2(value.x, value.y))
	queue_redraw()

func _reset() -> void:
	dragging = false
	active_touch = -1
	value = Vector2.ZERO
	moved.emit(value)
	queue_redraw()
