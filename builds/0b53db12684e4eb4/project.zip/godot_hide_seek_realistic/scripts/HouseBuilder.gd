extends Node3D

# Asset kit 3D procedural realistis: mansion gotik, furniture, dekorasi,
# chandelier, fireplace, halaman luar, dan spot sembunyi. Semua dibuat
# langsung dari mesh Godot agar project tetap ringan tanpa download asset.

var mat_floor := _make_mat(Color(0.32, 0.22, 0.14, 1), 0.45, 0.05)
var mat_floor_dark := _make_mat(Color(0.18, 0.14, 0.10, 1), 0.78, 0.0)
var mat_ground := _make_mat(Color(0.05, 0.06, 0.04, 1), 0.95, 0.0)
var mat_wall := _make_mat(Color(0.52, 0.48, 0.42, 1), 0.85, 0.0)
var mat_wall_trim := _make_mat(Color(0.30, 0.24, 0.18, 1), 0.72, 0.0)
var mat_wood := _make_mat(Color(0.30, 0.17, 0.08, 1), 0.55, 0.0)
var mat_wood_light := _make_mat(Color(0.55, 0.34, 0.16, 1), 0.55, 0.0)
var mat_dark := _make_mat(Color(0.055, 0.060, 0.070, 1), 0.86, 0.0)
var mat_fabric := _make_mat(Color(0.12, 0.16, 0.24, 1), 0.95, 0.0)
var mat_red_fabric := _make_mat(Color(0.32, 0.05, 0.04, 1), 0.94, 0.0)
var mat_metal := _make_mat(Color(0.40, 0.42, 0.42, 1), 0.30, 0.85)
var mat_gold := _make_mat(Color(0.85, 0.62, 0.22, 1), 0.25, 0.92)
var mat_glass := _make_glass_mat()
var mat_marble := _make_mat(Color(0.78, 0.77, 0.72, 1), 0.22, 0.10)
var mat_green := _make_mat(Color(0.09, 0.30, 0.12, 1), 0.88, 0.0)
var mat_dark_green := _make_mat(Color(0.04, 0.12, 0.05, 1), 0.92, 0.0)
var mat_lamp := _make_emission_mat(Color(1.0, 0.75, 0.38, 1), 1.6)
var mat_fire := _make_emission_mat(Color(1.0, 0.45, 0.10, 1), 4.5)
var mat_ember := _make_emission_mat(Color(0.95, 0.30, 0.05, 1), 2.0)

func _ready() -> void:
	_build_outside()
	_build_mansion()
	_build_lights()
	_build_audio()

func _make_mat(color: Color, roughness: float, metallic: float) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = roughness
	m.metallic = metallic
	return m

func _make_emission_mat(color: Color, energy: float) -> StandardMaterial3D:
	var m := _make_mat(color, 0.4, 0.0)
	m.emission_enabled = true
	m.emission = color
	m.emission_energy_multiplier = energy
	return m

func _make_glass_mat() -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.55, 0.75, 0.90, 0.32)
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.roughness = 0.05
	m.metallic = 0.10
	return m

func _box(name: String, pos: Vector3, size: Vector3, mat: Material, collision := true) -> MeshInstance3D:
	var mesh := BoxMesh.new()
	mesh.size = size
	var node := MeshInstance3D.new()
	node.name = name
	node.mesh = mesh
	node.material_override = mat
	node.position = pos
	add_child(node)
	if collision:
		var body := StaticBody3D.new()
		body.name = name + "_Collision"
		var shape := CollisionShape3D.new()
		var box := BoxShape3D.new()
		box.size = size
		shape.shape = box
		body.position = pos
		body.add_child(shape)
		add_child(body)
	return node

func _cylinder(name: String, pos: Vector3, radius: float, height: float, mat: Material, sides := 24, collision := false) -> MeshInstance3D:
	var mesh := CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius
	mesh.height = height
	mesh.radial_segments = sides
	var node := MeshInstance3D.new()
	node.name = name
	node.mesh = mesh
	node.material_override = mat
	node.position = pos
	add_child(node)
	if collision:
		var body := StaticBody3D.new()
		body.name = name + "_Collision"
		var shape := CollisionShape3D.new()
		var cyl := CylinderShape3D.new()
		cyl.radius = radius
		cyl.height = height
		shape.shape = cyl
		body.position = pos
		body.add_child(shape)
		add_child(body)
	return node

func _sphere(name: String, pos: Vector3, radius: float, mat: Material) -> MeshInstance3D:
	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2.0
	mesh.radial_segments = 24
	mesh.rings = 12
	var node := MeshInstance3D.new()
	node.name = name
	node.mesh = mesh
	node.material_override = mat
	node.position = pos
	add_child(node)
	return node

func _build_outside() -> void:
	# Halaman luar mansion: tanah gelap, pagar, dan siluet pohon
	_box("Outside_Ground", Vector3(0, -0.20, 0), Vector3(120, 0.2, 120), mat_ground)
	# pagar besi di sekeliling
	for x in range(-30, 32, 3):
		_box("Outside_Fence_N", Vector3(x, 0.55, -22), Vector3(0.12, 1.2, 0.12), mat_metal, false)
		_box("Outside_Fence_S", Vector3(x, 0.55, 22), Vector3(0.12, 1.2, 0.12), mat_metal, false)
	for z in range(-22, 24, 3):
		_box("Outside_Fence_W", Vector3(-30, 0.55, z), Vector3(0.12, 1.2, 0.12), mat_metal, false)
		_box("Outside_Fence_E", Vector3(30, 0.55, z), Vector3(0.12, 1.2, 0.12), mat_metal, false)
	# pohon siluet
	for i in 24:
		var ang := randf() * TAU
		var rad := randf_range(20.0, 28.0)
		var pos := Vector3(cos(ang) * rad, 0.0, sin(ang) * rad)
		_add_tree(pos)
	# Atap mansion gabled: dua slab miring membentuk segitiga di atas tembok
	# Tembok atas y=3.0, ridge di y=4.6 di z=0; eaves di y=3.05 di z=±12.5
	# Slope rise = 1.55 over horizontal 12.5 -> angle = atan(1.55/12.5) ≈ 7.07°
	# Slab dipasang sebagai box tipis lalu di-rotate; pakai pivot Node3D agar transformasinya benar
	_make_roof_slab(-1.0)
	_make_roof_slab(1.0)
	# Punggung atap (ridge) di tengah
	_box("Roof_Ridge", Vector3(0, 4.62, 0), Vector3(31.4, 0.18, 0.35), mat_wall_trim, false)
	# Gable triangle (panel kayu segitiga di ujung barat/timur)
	for sx in [-15.20, 15.20]:
		var gable_panel := _box("Roof_Gable_%s" % sx, Vector3(sx, 3.78, 0), Vector3(0.10, 1.5, 8.0), mat_wood, false)
		gable_panel.scale = Vector3(1, 1, 1)
	# Cerobong asap di sudut
	_box("Chimney_Base", Vector3(-10.0, 4.2, 6.0), Vector3(1.4, 2.6, 1.4), mat_wall_trim, false)
	_box("Chimney_Cap", Vector3(-10.0, 5.6, 6.0), Vector3(1.7, 0.18, 1.7), mat_dark, false)
	_box("Chimney_Top", Vector3(-10.0, 5.75, 6.0), Vector3(0.5, 0.18, 0.5), mat_dark, false)
	# Lampu teras (dua lampu kuning di samping pintu)
	for sx in [-2.6, 2.6]:
		var lamp_post := _box("Porch_Lamp_Post_%s" % sx, Vector3(sx, 1.2, -13.0), Vector3(0.08, 2.4, 0.08), mat_metal, false)
		var lamp_head := _box("Porch_Lamp_Head_%s" % sx, Vector3(sx, 2.5, -13.0), Vector3(0.35, 0.35, 0.35), mat_lamp, false)
		var lpt := OmniLight3D.new()
		lpt.position = Vector3(sx, 2.5, -13.0)
		lpt.light_color = Color(1.0, 0.78, 0.42, 1)
		lpt.light_energy = 1.4
		lpt.omni_range = 6.5
		add_child(lpt)
	# tangga porch di pintu depan
	for i in range(3):
		_box("Porch_Step_%d" % i, Vector3(0, 0.10 - i * 0.10, -13.0 - i * 0.6), Vector3(4.0, 0.20, 0.8), mat_marble)
	_box("Porch_Slab", Vector3(0, 0.05, -12.2), Vector3(5.0, 0.18, 1.4), mat_marble, false)
	# Pilar marmer kanan/kiri pintu masuk
	for sx in [-2.0, 2.0]:
		_cylinder("Porch_Column_%s" % sx, Vector3(sx, 1.5, -12.8), 0.22, 3.0, mat_marble, 16, false)
		_box("Porch_Column_Cap_%s" % sx, Vector3(sx, 3.0, -12.8), Vector3(0.6, 0.18, 0.6), mat_marble, false)
	# Jalan setapak dari pagar ke pintu
	for i in range(5):
		_box("Path_Stone_%d" % i, Vector3(0, -0.15, -14.0 - i * 1.6), Vector3(2.0, 0.06, 1.2), mat_marble, false)

func _make_roof_slab(side: float) -> void:
	# side = -1 for north (negative z), +1 for south
	# Roof slab spans the mansion + small overhang.
	# Ridge: z=0, y=4.6. Eave: z=±12.6 (overhang), y=3.05.
	# Place slab as a child of a pivot rotated around X at the ridge.
	var pivot := Node3D.new()
	pivot.name = "Roof_Pivot_%s" % str(side)
	pivot.position = Vector3(0, 4.6, 0)
	# Slope angle: rise 1.55m over horizontal 12.6m -> atan2(1.55, 12.6) rad
	var ang_rad: float = atan2(1.55, 12.6)
	pivot.rotation = Vector3(side * ang_rad, 0, 0)
	add_child(pivot)
	# slab extends in +/-z direction; we want it on the SIDE of side
	# slab local position offset: in -z direction by half its length (so it hangs off pivot toward eave)
	var slab_len: float = sqrt(1.55 * 1.55 + 12.6 * 12.6) + 0.4
	var slab := MeshInstance3D.new()
	slab.name = "Roof_Slab_%s" % str(side)
	var bm := BoxMesh.new()
	bm.size = Vector3(31.6, 0.22, slab_len)
	slab.mesh = bm
	slab.material_override = mat_dark
	# Position so one edge is at pivot (ridge) and the other end goes in +z direction relative to pivot
	# For side=-1 (north), pivot is rotated -ang, so its +z goes toward -z world (toward north).
	# Wait: rotation around X by negative angle rotates +z toward +y? Let's check:
	# +z axis after rotation by -ang around X: (0, sin(ang), cos(ang)).
	# For side=-1, ang_rad is positive. side*ang = -ang. So rotated +z = (0, sin(-ang), cos(-ang)) = (0, -sin(ang), cos(ang)) - that goes "down" relative to world Y, going +z world.
	# Hmm. Simpler: side=-1 should point to -z world side. So local slab placed at -slab_len/2 in local z for side=-1.
	slab.position = Vector3(0, 0, -side * slab_len * 0.5)
	pivot.add_child(slab)
	# add thin overlay shingles for texture variety
	var shingle := MeshInstance3D.new()
	shingle.name = "Roof_Shingles_%s" % str(side)
	var sm := BoxMesh.new()
	sm.size = Vector3(31.2, 0.04, slab_len - 0.2)
	shingle.mesh = sm
	shingle.material_override = mat_dark_green
	shingle.position = Vector3(0, 0.14, -side * slab_len * 0.5)
	pivot.add_child(shingle)

func _add_tree(pos: Vector3) -> void:
	# Pinus cemara: trunk pendek + tiga lapis canopy berbentuk kerucut (mengecil ke atas)
	var trunk_h := randf_range(1.0, 1.6)
	_cylinder("Outside_Tree_Trunk", pos + Vector3(0, trunk_h * 0.5, 0), 0.22, trunk_h, mat_wood, 12, false)
	var base_y := trunk_h
	var layer_h := randf_range(1.2, 1.6)
	var base_r := randf_range(1.6, 2.4)
	for i in 4:
		var t := float(i)
		var scale_factor: float = lerp(1.0, 0.25, t / 3.0)
		var cone := MeshInstance3D.new()
		cone.name = "Outside_Tree_Cone_%d" % i
		var m := CylinderMesh.new()
		m.top_radius = 0.05
		m.bottom_radius = base_r * scale_factor
		m.height = layer_h
		m.radial_segments = 14
		cone.mesh = m
		cone.material_override = mat_dark_green
		cone.position = pos + Vector3(0, base_y + layer_h * 0.5, 0)
		add_child(cone)
		base_y += layer_h * 0.7

func _build_mansion() -> void:
	# lantai, ceiling, dan basement
	_box("Floor_Main_Oak", Vector3(0, -0.05, 0), Vector3(30, 0.1, 24), mat_floor)
	_box("Ceiling_Main", Vector3(0, 3.05, 0), Vector3(30, 0.12, 24), mat_wall)
	_box("Basement_Floor_Concrete", Vector3(0, -3.05, 0), Vector3(13, 0.1, 9), mat_floor_dark)
	# tembok luar tebal
	_box("Wall_North", Vector3(0, 1.5, -12), Vector3(30, 3, 0.35), mat_wall)
	_box("Wall_South", Vector3(0, 1.5, 12), Vector3(30, 3, 0.35), mat_wall)
	_box("Wall_West", Vector3(-15, 1.5, 0), Vector3(0.35, 3, 24), mat_wall)
	_box("Wall_East", Vector3(15, 1.5, 0), Vector3(0.35, 3, 24), mat_wall)
	# lis tembok dan pilar biar realistis
	for z in [-11.8, 11.8]:
		_box("Wall_Trim_Z_%s" % z, Vector3(0, 0.18, z), Vector3(29.5, 0.28, 0.18), mat_wall_trim, false)
		_box("Wall_Crown_Z_%s" % z, Vector3(0, 2.75, z), Vector3(29.5, 0.20, 0.16), mat_wall_trim, false)
	for x in [-14.8, 14.8]:
		_box("Wall_Trim_X_%s" % x, Vector3(x, 0.18, 0), Vector3(0.18, 0.28, 23.5), mat_wall_trim, false)
		_box("Wall_Crown_X_%s" % x, Vector3(x, 2.75, 0), Vector3(0.16, 0.20, 23.5), mat_wall_trim, false)
	for x in [-14, -7, 0, 7, 14]:
		for z in [-11.7, 11.7]:
			_cylinder("Wood_Pillar", Vector3(x, 1.45, z), 0.16, 2.8, mat_wood_light, 16, false)
	# ruangan dengan celah pintu
	for x in [-5, 5]:
		_box("RoomWall_A_%s" % x, Vector3(x, 1.5, -6.1), Vector3(0.25, 3, 8.4), mat_wall)
		_box("RoomWall_B_%s" % x, Vector3(x, 1.5, 6.9), Vector3(0.25, 3, 8.4), mat_wall)
	for z in [-3.7, 3.7]:
		_box("HallWall_L_%s" % z, Vector3(-9.8, 1.5, z), Vector3(8.5, 3, 0.25), mat_wall)
		_box("HallWall_R_%s" % z, Vector3(9.8, 1.5, z), Vector3(8.5, 3, 0.25), mat_wall)
	# basement
	_box("Basement_Back", Vector3(0, -1.5, -4.5), Vector3(13, 3, 0.3), mat_wall)
	_box("Basement_Front", Vector3(0, -1.5, 4.5), Vector3(13, 3, 0.3), mat_wall)
	_box("Basement_Left", Vector3(-6.5, -1.5, 0), Vector3(0.3, 3, 9), mat_wall)
	_box("Basement_Right", Vector3(6.5, -1.5, 0), Vector3(0.3, 3, 9), mat_wall)
	_box("Basement_Ramp", Vector3(-3, -1.4, 8.2), Vector3(4.2, 0.25, 6.4), mat_dark)
	_build_windows()
	_build_furniture_sets()
	_build_decor()
	_build_basement_props()
	_add_door(Vector3(0, 1.2, -11.76), "FrontDoor")
	_add_fireplace(Vector3(13.8, 0.0, -4.0))
	_build_paintings_on_walls()
	_build_chandeliers()

func _build_windows() -> void:
	for x in [-10, -2.5, 5, 12]:
		_add_window(Vector3(x, 1.65, -11.79), true)
		_add_window(Vector3(x, 1.65, 11.79), true)
	for z in [-7.5, 0, 7.5]:
		_add_window(Vector3(-14.79, 1.65, z), false)
		_add_window(Vector3(14.79, 1.65, z), false)

func _add_window(pos: Vector3, horizontal: bool) -> void:
	var frame_size := Vector3(1.9, 1.25, 0.08) if horizontal else Vector3(0.08, 1.25, 1.9)
	_box("Window_Glass", pos, frame_size, mat_glass, false)
	if horizontal:
		_box("Window_Frame_Top", pos + Vector3(0, 0.68, 0), Vector3(2.05, 0.08, 0.12), mat_wood, false)
		_box("Window_Frame_Bottom", pos + Vector3(0, -0.68, 0), Vector3(2.05, 0.08, 0.12), mat_wood, false)
		_box("Window_Frame_Left", pos + Vector3(-1.03, 0, 0), Vector3(0.08, 1.4, 0.12), mat_wood, false)
		_box("Window_Frame_Right", pos + Vector3(1.03, 0, 0), Vector3(0.08, 1.4, 0.12), mat_wood, false)
		_box("Window_Cross", pos, Vector3(2.0, 0.04, 0.04), mat_wood, false)
		_box("Window_Cross_V", pos, Vector3(0.04, 1.3, 0.04), mat_wood, false)
	else:
		_box("Window_Frame_Top", pos + Vector3(0, 0.68, 0), Vector3(0.12, 0.08, 2.05), mat_wood, false)
		_box("Window_Frame_Bottom", pos + Vector3(0, -0.68, 0), Vector3(0.12, 0.08, 2.05), mat_wood, false)
		_box("Window_Frame_Left", pos + Vector3(0, 0, -1.03), Vector3(0.12, 1.4, 0.08), mat_wood, false)
		_box("Window_Frame_Right", pos + Vector3(0, 0, 1.03), Vector3(0.12, 1.4, 0.08), mat_wood, false)
		_box("Window_Cross", pos, Vector3(0.04, 0.04, 2.0), mat_wood, false)
		_box("Window_Cross_V", pos, Vector3(0.04, 1.3, 0.04), mat_wood, false)

func _build_furniture_sets() -> void:
	_add_sofa(Vector3(-10, 0.5, -7))
	_add_sofa(Vector3(-10, 0.5, -4.8))
	_add_coffee_table(Vector3(-10, 0.45, -5.9))
	_add_table(Vector3(-8, 0.55, -1))
	_add_bed(Vector3(9, 0.45, -7))
	_add_wardrobe(Vector3(12, 1.2, -3), "Wardrobe_HideSpot")
	_add_wardrobe(Vector3(-12, 1.2, 7), "Storage_HideSpot")
	_add_kitchen(Vector3(8, 0.5, 7))
	_add_bathroom(Vector3(-9.5, 0.45, 7.4))
	_add_bookshelf(Vector3(2.5, 1.15, -9.8), "Library_Shelf_HideSpot")
	_add_piano(Vector3(0.5, 0.55, 7.6))
	_add_staircase(Vector3(-3.0, 0.0, 8.8))

func _add_sofa(pos: Vector3) -> void:
	_box("Sofa_Base", pos, Vector3(3.2, 0.7, 1.05), mat_fabric)
	_box("Sofa_Back", pos + Vector3(0, 0.55, -0.50), Vector3(3.3, 1.0, 0.25), mat_fabric)
	_box("Sofa_Left_Arm", pos + Vector3(-1.75, 0.40, 0.05), Vector3(0.25, 0.8, 1.1), mat_fabric)
	_box("Sofa_Right_Arm", pos + Vector3(1.75, 0.40, 0.05), Vector3(0.25, 0.8, 1.1), mat_fabric)
	_box("Sofa_HideSpot", pos + Vector3(0, 0.4, 1.1), Vector3(3.2, 0.8, 0.25), mat_dark, false)

func _add_coffee_table(pos: Vector3) -> void:
	_box("Glass_Coffee_Table", pos + Vector3(0, 0.42, 0), Vector3(2.2, 0.10, 1.0), mat_glass, false)
	for x in [-0.9, 0.9]:
		for z in [-0.35, 0.35]:
			_cylinder("Coffee_Table_Metal_Leg", pos + Vector3(x, 0.15, z), 0.045, 0.55, mat_metal, 12, false)

func _add_table(pos: Vector3) -> void:
	_box("Dining_Table", pos + Vector3(0, 0.5, 0), Vector3(3.2, 0.22, 1.55), mat_wood)
	for x in [-1.25, 1.25]:
		for z in [-0.58, 0.58]:
			_box("Table_Leg", pos + Vector3(x, 0.1, z), Vector3(0.18, 0.8, 0.18), mat_wood)
	for x in [-2.1, -1.45, 1.45, 2.1]:
		_box("Dining_Chair", pos + Vector3(x, 0.32, 0), Vector3(0.5, 0.45, 0.55), mat_wood_light)
		_box("Dining_Chair_Back", pos + Vector3(x, 0.85, -0.22), Vector3(0.5, 0.8, 0.12), mat_wood_light)
	_box("Under_Table_HideSpot", pos + Vector3(0, 0.25, 0), Vector3(2.45, 0.5, 1.05), mat_dark, false)
	# candelabra di atas meja
	_sphere("Dining_Candle_Glow", pos + Vector3(0, 0.95, 0), 0.08, mat_lamp)

func _add_bed(pos: Vector3) -> void:
	_box("Bed_Frame", pos, Vector3(3.2, 0.55, 2.15), mat_wood)
	_box("Bed_Mattress", pos + Vector3(0, 0.35, 0), Vector3(2.95, 0.3, 1.9), mat_fabric)
	_box("Bed_Blanket", pos + Vector3(0, 0.58, 0.35), Vector3(2.9, 0.14, 1.1), mat_red_fabric, false)
	_box("Bed_Pillow_A", pos + Vector3(-0.7, 0.72, -0.72), Vector3(0.8, 0.18, 0.38), mat_marble, false)
	_box("Bed_Pillow_B", pos + Vector3(0.7, 0.72, -0.72), Vector3(0.8, 0.18, 0.38), mat_marble, false)
	_box("Bed_Headboard", pos + Vector3(0, 1.05, -1.05), Vector3(3.2, 1.2, 0.10), mat_wood_light, false)
	_box("Under_Bed_HideSpot", pos + Vector3(0, 0.15, 0), Vector3(2.6, 0.25, 1.6), mat_dark, false)

func _add_wardrobe(pos: Vector3, hide_name: String) -> void:
	_box(hide_name, pos, Vector3(1.6, 2.45, 0.85), mat_wood)
	_box(hide_name + "_Door_L", pos + Vector3(-0.42, 0, -0.45), Vector3(0.72, 2.25, 0.08), mat_wood_light, false)
	_box(hide_name + "_Door_R", pos + Vector3(0.42, 0, -0.45), Vector3(0.72, 2.25, 0.08), mat_wood_light, false)
	var handle_l := _cylinder(hide_name + "_Handle_L", pos + Vector3(-0.12, 0.1, -0.52), 0.035, 0.35, mat_gold, 12, false)
	handle_l.rotation_degrees.x = 90
	var handle_r := _cylinder(hide_name + "_Handle_R", pos + Vector3(0.12, 0.1, -0.52), 0.035, 0.35, mat_gold, 12, false)
	handle_r.rotation_degrees.x = 90

func _add_kitchen(pos: Vector3) -> void:
	_box("Kitchen_Counter_Marble", pos, Vector3(4.5, 1, 0.9), mat_marble)
	_box("Kitchen_Base_Dark", pos + Vector3(0, -0.15, 0), Vector3(4.6, 0.75, 0.92), mat_dark)
	_box("Kitchen_Cabinet", pos + Vector3(0, 1.55, -0.1), Vector3(4.2, 1, 0.45), mat_wood)
	_box("Fridge_Metal", pos + Vector3(2.95, 0.9, 0.1), Vector3(0.95, 1.85, 0.95), mat_metal)
	_box("Sink", pos + Vector3(-0.9, 0.58, -0.05), Vector3(0.75, 0.08, 0.45), mat_metal, false)
	_cylinder("Faucet", pos + Vector3(-0.9, 1.08, -0.12), 0.035, 0.65, mat_metal, 12, false)
	_box("Oven_Door", pos + Vector3(0.75, 0.12, -0.47), Vector3(0.95, 0.55, 0.05), mat_glass, false)

func _add_bathroom(pos: Vector3) -> void:
	_box("Bathtub", pos + Vector3(0.0, 0.25, 0.0), Vector3(2.2, 0.55, 1.05), mat_marble)
	_box("Bathtub_Water", pos + Vector3(0.0, 0.58, 0.0), Vector3(2.0, 0.04, 0.85), mat_glass, false)
	_cylinder("Toilet_Base", pos + Vector3(-1.8, 0.32, 0.0), 0.38, 0.55, mat_marble, 20, false)
	_cylinder("Toilet_Tank", pos + Vector3(-1.8, 0.78, -0.38), 0.28, 0.50, mat_marble, 16, false)
	_box("Bathroom_Mirror", pos + Vector3(1.65, 1.55, -0.55), Vector3(0.08, 0.85, 1.1), mat_glass, false)

func _add_bookshelf(pos: Vector3, hide_name: String) -> void:
	_box(hide_name, pos, Vector3(3.4, 2.3, 0.55), mat_wood)
	for y in [0.35, 0.85, 1.35, 1.85]:
		_box("Shelf_Board", Vector3(pos.x, y, pos.z - 0.32), Vector3(3.25, 0.08, 0.12), mat_wood_light, false)
		for i in range(8):
			var bx := pos.x - 1.35 + i * 0.38
			_box("Book", Vector3(bx, y + 0.18, pos.z - 0.34), Vector3(0.18, randf_range(0.32, 0.55), 0.12), _make_mat(Color(randf_range(0.12,0.65), randf_range(0.08,0.45), randf_range(0.08,0.45), 1), 0.9, 0), false)

func _add_piano(pos: Vector3) -> void:
	_box("Old_Piano_Body", pos + Vector3(0, 0.6, 0), Vector3(2.2, 1.0, 0.75), mat_dark)
	_box("Piano_Keys", pos + Vector3(0, 0.85, -0.43), Vector3(1.85, 0.08, 0.12), mat_marble, false)
	_box("Piano_Bench", pos + Vector3(0, 0.25, -1.15), Vector3(1.2, 0.22, 0.45), mat_wood)

func _add_staircase(pos: Vector3) -> void:
	for i in range(8):
		_box("Stair_Step_%d" % i, pos + Vector3(i * 0.45, 0.10 + i * 0.16, -i * 0.28), Vector3(0.55, 0.18, 1.25), mat_wood)
	var railing := _cylinder("Stair_Railing_A", pos + Vector3(1.3, 1.1, -1.3), 0.05, 3.6, mat_gold, 12, false)
	railing.rotation_degrees.z = 62

func _build_decor() -> void:
	# karpet besar dengan motif tepi
	_box("Living_Rug", Vector3(-10, 0.01, -5.9), Vector3(4.2, 0.035, 3.0), mat_red_fabric, false)
	_box("Living_Rug_Border", Vector3(-10, 0.012, -5.9), Vector3(4.6, 0.034, 3.4), mat_gold, false)
	_box("Dining_Rug", Vector3(-8, 0.012, -1), Vector3(4.5, 0.035, 2.8), mat_fabric, false)
	# crates dan tanaman sebagai cover tambahan
	for i in range(12):
		_box("Realistic_Crate_%d" % i, Vector3(randf_range(-12,12),0.35,randf_range(-9,9)), Vector3(0.72,0.72,0.72), mat_wood)
	for pos in [Vector3(-13,0.45,-9), Vector3(13,0.45,-9), Vector3(-13,0.45,9), Vector3(13,0.45,9), Vector3(2,0.45,2), Vector3(-4, 0.45, -10), Vector3(4, 0.45, -10)]:
		_add_plant(pos)
	# Lampu standing kecil di sudut basement
	_sphere("Basement_Bulb_A", Vector3(-5, -1.0, -3), 0.18, mat_lamp)
	_sphere("Basement_Bulb_B", Vector3(5, -1.0, 3), 0.18, mat_lamp)

func _build_paintings_on_walls() -> void:
	# Lukisan menempel di tembok utara (z=-12) dan selatan (z=12) dengan rotasi yg benar
	var xs := [-12, -8, -4, 0, 4, 8, 12]
	for i in xs.size():
		var x: float = xs[i]
		var rng := i + 1
		var col_a := Color(randf_range(0.15, 0.6), randf_range(0.15, 0.55), randf_range(0.15, 0.55), 1)
		_box("Painting_Frame_N_%d" % rng, Vector3(x, 2.05, -11.7), Vector3(0.95, 0.7, 0.05), mat_gold, false)
		_box("Painting_Canvas_N_%d" % rng, Vector3(x, 2.05, -11.66), Vector3(0.78, 0.55, 0.03), _make_mat(col_a, 0.85, 0.0), false)
		var col_b := Color(randf_range(0.15, 0.6), randf_range(0.15, 0.55), randf_range(0.15, 0.55), 1)
		_box("Painting_Frame_S_%d" % rng, Vector3(x, 2.05, 11.7), Vector3(0.95, 0.7, 0.05), mat_gold, false)
		_box("Painting_Canvas_S_%d" % rng, Vector3(x, 2.05, 11.66), Vector3(0.78, 0.55, 0.03), _make_mat(col_b, 0.85, 0.0), false)
	# Lukisan portrait besar di antara pilar dinding timur dan barat
	for z in [-6, 0, 6]:
		_box("Painting_Frame_W_%d" % int(z), Vector3(-14.7, 2.05, z), Vector3(0.05, 0.95, 0.78), mat_gold, false)
		_box("Painting_Canvas_W_%d" % int(z), Vector3(-14.66, 2.05, z), Vector3(0.03, 0.78, 0.62), _make_mat(Color(randf_range(0.2,0.6), randf_range(0.2,0.5), randf_range(0.2,0.5), 1), 0.85, 0.0), false)
		_box("Painting_Frame_E_%d" % int(z), Vector3(14.7, 2.05, z), Vector3(0.05, 0.95, 0.78), mat_gold, false)
		_box("Painting_Canvas_E_%d" % int(z), Vector3(14.66, 2.05, z), Vector3(0.03, 0.78, 0.62), _make_mat(Color(randf_range(0.2,0.6), randf_range(0.2,0.5), randf_range(0.2,0.5), 1), 0.85, 0.0), false)

func _build_chandeliers() -> void:
	# 3 chandelier elegan di sepanjang sumbu mansion
	for x in [-9.0, 0.0, 9.0]:
		_add_chandelier(Vector3(x, 2.65, 0.0))

func _add_chandelier(pos: Vector3) -> void:
	# rantai
	_cylinder("Chandelier_Chain", pos + Vector3(0, 0.30, 0), 0.025, 0.4, mat_metal, 8, false)
	# tubuh utama
	_sphere("Chandelier_Body", pos + Vector3(0, -0.10, 0), 0.22, mat_gold)
	# lengan + bulb
	var arm_count := 6
	for i in arm_count:
		var ang := (TAU / float(arm_count)) * float(i)
		var ax := cos(ang) * 0.42
		var az := sin(ang) * 0.42
		var arm := _cylinder("Chandelier_Arm_%d" % i, pos + Vector3(ax * 0.5, -0.05, az * 0.5), 0.025, 0.55, mat_gold, 8, false)
		arm.rotation.z = -ang
		_sphere("Chandelier_Crystal_%d" % i, pos + Vector3(ax, -0.18, az), 0.06, mat_glass)
		_sphere("Chandelier_Bulb_%d" % i, pos + Vector3(ax, -0.06, az), 0.08, mat_lamp)
	# OmniLight terpasang sebagai sumber cahaya
	var ol := OmniLight3D.new()
	ol.name = "Chandelier_Light"
	ol.position = pos + Vector3(0, -0.18, 0)
	ol.light_color = Color(1.0, 0.78, 0.46, 1)
	ol.light_energy = 2.2
	ol.omni_range = 9.5
	ol.shadow_enabled = true
	add_child(ol)

func _add_fireplace(pos: Vector3) -> void:
	# Perapian dari batu marble dengan api emisif. pos = base center, menempel di dinding timur (x=14.8)
	_box("Fireplace_Surround", pos + Vector3(-0.20, 1.05, 0), Vector3(0.5, 2.1, 2.6), mat_marble)
	_box("Fireplace_Mantle", pos + Vector3(-0.45, 1.95, 0), Vector3(0.9, 0.14, 3.0), mat_wood_light, false)
	# bukaan
	_box("Fireplace_Interior", pos + Vector3(-0.35, 0.65, 0), Vector3(0.30, 1.05, 1.55), mat_dark, false)
	# kayu bakar
	for i in 5:
		var lx := -0.42 + randf_range(-0.05, 0.05)
		var ly := 0.30
		var lz := -0.6 + i * 0.30
		var log := _cylinder("Fireplace_Log_%d" % i, pos + Vector3(lx, ly, lz), 0.08, 0.55, mat_wood, 8, false)
		log.rotation_degrees.z = 90
	# bara api
	_sphere("Fireplace_Fire_Core", pos + Vector3(-0.40, 0.45, 0), 0.32, mat_fire)
	_sphere("Fireplace_Fire_Top", pos + Vector3(-0.40, 0.70, 0), 0.20, mat_fire)
	_sphere("Fireplace_Ember", pos + Vector3(-0.40, 0.30, -0.30), 0.10, mat_ember)
	_sphere("Fireplace_Ember_B", pos + Vector3(-0.40, 0.30, 0.30), 0.10, mat_ember)
	# Cahaya api hangat
	var fl := OmniLight3D.new()
	fl.name = "Fireplace_Glow"
	fl.position = pos + Vector3(-0.4, 0.55, 0)
	fl.light_color = Color(1.0, 0.55, 0.20, 1)
	fl.light_energy = 3.5
	fl.omni_range = 7.5
	fl.shadow_enabled = true
	add_child(fl)

func _add_plant(pos: Vector3) -> void:
	_cylinder("Plant_Pot", pos, 0.32, 0.55, mat_wood, 18, false)
	_cylinder("Plant_Stem", pos + Vector3(0,0.55,0), 0.035, 0.65, mat_green, 10, false)
	for i in range(6):
		var leaf := _sphere("Plant_Leaf", pos + Vector3(randf_range(-0.32,0.32), 1.0 + randf_range(-0.10,0.25), randf_range(-0.32,0.32)), 0.18, mat_green)
		leaf.scale = Vector3(1.4, 0.45, 0.8)

func _build_basement_props() -> void:
	for z in [-3.4, 3.4]:
		var pipe := _cylinder("Basement_Pipe", Vector3(-5.9, -0.35, z), 0.06, 11.0, mat_metal, 16, false)
		pipe.rotation_degrees.x = 90
	for x in [-3.5, -1.5, 1.5, 3.5]:
		_box("Basement_Shelf", Vector3(x, -2.0, -3.6), Vector3(1.2, 1.75, 0.35), mat_wood)
		_box("Basement_Box_HideSpot", Vector3(x, -2.65, -2.95), Vector3(0.9, 0.65, 0.9), mat_dark, false)

func _add_door(pos: Vector3, door_name: String) -> void:
	var d := _box(door_name, pos, Vector3(1.45, 2.4, 0.12), mat_wood)
	d.add_to_group("door")
	_box(door_name + "_Panel_A", pos + Vector3(0, 0.35, -0.07), Vector3(1.05, 0.75, 0.05), mat_wood_light, false)
	_box(door_name + "_Panel_B", pos + Vector3(0, -0.55, -0.07), Vector3(1.05, 0.65, 0.05), mat_wood_light, false)
	_sphere(door_name + "_Knob", pos + Vector3(0.52, 0.02, -0.12), 0.08, mat_gold)

func _build_lights() -> void:
	# Moonlight halus dari pintu
	var sun := DirectionalLight3D.new()
	sun.name = "Soft_Window_Moonlight"
	sun.rotation_degrees = Vector3(-45, -30, 0)
	sun.light_energy = 0.35
	sun.shadow_enabled = true
	add_child(sun)
	# lampu hangat tambahan
	for pos in [Vector3(-8,2.45,-7), Vector3(8,2.45,-7), Vector3(-8,2.45,6), Vector3(8,2.45,6), Vector3(0,-0.8,0)]:
		var light := OmniLight3D.new()
		light.name = "Warm_Realistic_Lamp"
		light.position = pos
		light.light_color = Color(1.0, 0.78, 0.48, 1)
		light.light_energy = 1.6
		light.omni_range = 7.5
		light.shadow_enabled = true
		add_child(light)

func _build_audio() -> void:
	var ambience := AudioStreamPlayer3D.new()
	ambience.name = "Tense_Ambience"
	ambience.stream = load("res://assets/audio/ambience_house.wav")
	ambience.volume_db = -14
	ambience.autoplay = true
	ambience.max_distance = 40
	add_child(ambience)
