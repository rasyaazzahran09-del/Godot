extends Node3D

const PLAYER_SCENE := preload("res://scenes/Player.tscn")

var state := "hiding"
var time_left: int = 35
var _seek_seconds: int = 240
var _tick := 0.0
var _players_spawned := false

@onready var players_root: Node3D = $Players
@onready var spawn_points: Node3D = $SpawnPoints
@onready var ui: CanvasLayer = $UI

func _ready() -> void:
	time_left = NetworkManager.hide_seconds
	_seek_seconds = NetworkManager.seek_seconds
	if multiplayer.multiplayer_peer == null or NetworkManager.players.is_empty():
		var cam: Node = get_node_or_null("CinematicCamera")
		if cam and cam is Camera3D:
			(cam as Camera3D).current = true
		_update_ui()
		return
	_spawn_players()
	_players_spawned = true
	_update_ui()
	if multiplayer.is_server():
		set_process(true)

func _process(delta: float) -> void:
	if not multiplayer.is_server():
		return
	_tick += delta
	if _tick >= 1.0:
		_tick = 0.0
		time_left -= 1
		_update_timer.rpc(state, time_left)
		if state == "hiding" and time_left <= 0:
			state = "seeking"
			time_left = _seek_seconds
			_update_timer.rpc(state, time_left)
		elif state == "seeking":
			_check_win_conditions()

func _spawn_players() -> void:
	var ids: Array = NetworkManager.players.keys()
	ids.sort()
	for i in ids.size():
		var id: int = ids[i]
		var p = PLAYER_SCENE.instantiate()
		p.player_id = id
		p.role = NetworkManager.players[id].get("role", "Hider")
		p.caught.connect(_on_player_caught)
		players_root.add_child(p, true)
		var spawn := spawn_points.get_child(i % spawn_points.get_child_count()) as Marker3D
		p.global_transform = spawn.global_transform

func _on_player_caught(player_id: int) -> void:
	if not multiplayer.is_server(): return
	if NetworkManager.players.has(player_id):
		NetworkManager.players[player_id]["caught"] = true
		_check_win_conditions()

func _check_win_conditions() -> void:
	var hider_total := 0
	var caught_total := 0
	for id in NetworkManager.players.keys():
		if NetworkManager.players[id].get("role") == "Hider":
			hider_total += 1
			if NetworkManager.players[id].get("caught") == true:
				caught_total += 1
	if hider_total > 0 and caught_total >= hider_total:
		_end_game.rpc("Seeker menang! Semua hider tertangkap.")
	elif time_left <= 0:
		_end_game.rpc("Hider menang! Waktu pencarian habis.")

@rpc("authority", "reliable", "call_local")
func _update_timer(new_state: String, seconds: int) -> void:
	state = new_state
	time_left = seconds
	_update_ui()

@rpc("authority", "reliable", "call_local")
func _end_game(message: String) -> void:
	state = "ended"
	if ui and ui.has_method("show_result"):
		ui.show_result(message)
	set_process(false)

func _update_ui() -> void:
	if ui and ui.has_method("set_match_info"):
		var my_id: int = multiplayer.get_unique_id()
		var role: String = str(NetworkManager.players.get(my_id, {}).get("role", "-"))
		ui.set_match_info(role, state, time_left)
