extends Control

@onready var name_input: LineEdit = $Center/Panel/VBox/NameInput

func _ready() -> void:
	if NetworkManager.player_name != "":
		name_input.text = NetworkManager.player_name
	$Center/Panel/VBox/ContinueButton.pressed.connect(_continue)
	$Center/Panel/VBox/QuickPlayButton.pressed.connect(_quick_play)
	name_input.text_submitted.connect(func(_t): _continue())
	name_input.grab_focus()

func _continue() -> void:
	var nm := name_input.text.strip_edges()
	if nm == "":
		nm = "Player%d" % randi_range(100, 999)
	NetworkManager.player_name = nm.left(18)
	get_tree().change_scene_to_file("res://scenes/MainMenu.tscn")

func _quick_play() -> void:
	if name_input.text.strip_edges() == "":
		name_input.text = "Guest%d" % randi_range(100, 999)
	_continue()

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		get_tree().quit()
