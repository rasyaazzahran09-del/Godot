# HideSeek Mansion 3D — Realistic Edition

Multiplayer hide-and-seek 3D di mansion gelap, dibuat dengan **Godot 4.3** (Forward Plus renderer).

## Cara Pakai

1. Buka **Godot 4.3** (https://godotengine.org/download).
2. Klik **Import**, pilih file `project.godot` di folder ini.
3. Tunggu Godot selesai mengimpor aset (sekali saja, akan membuat folder `.godot/`).
4. Tekan **F5** atau klik tombol Play untuk menjalankan game. Scene utama: `res://scenes/Login.tscn`.

## Alur Game

```
Login (input nama)
  ↓
MainMenu (Mulai Cepat / Buat Room / Gabung Room / Pengaturan / Keluar)
  ↓
   ├─ CreateRoom (nama room, port, max player, mode permainan) → host
   ├─ JoinRoom (IP + port host) → join
   └─ MulaiCepat → langsung host room
  ↓
Lobby (info room + daftar pemain + tombol Salin Info / Mulai Game)
  ↓
GameWorld (mansion 3D, Seeker vs Hider)
```

## Fitur Utama

### Multiplayer
- **ENet** untuk koneksi LAN/Internet.
- **Maks. 8 pemain** per room.
- Host pertama otomatis jadi **Seeker**, sisanya **Hider**.
- Port default `7777`.

### Mode Permainan (pilih saat membuat room)
| Mode    | Sembunyi | Pencarian |
|---------|----------|-----------|
| Classic | 35s      | 240s      |
| Fast    | 20s      | 120s      |
| Long    | 60s      | 360s      |

### Tampilan
- **Tema gelap + aksen emas** untuk semua menu (Login, MainMenu, CreateRoom, JoinRoom, Lobby).
- **Background animasi** menggunakan shader (`assets/shaders/menu_background.gdshader`) berupa gradient + fog + vignette.
- **HUD in-game** dengan timer (countdown), role, status, dan nama room.
- **Virtual joystick + tombol mobile** (jump / sprint / crouch / interact) yang otomatis muncul di build mobile.
- **End-game panel** menampilkan hasil + tombol kembali ke Lobby / Menu.

### Mansion 3D (procedural)
Semua aset 3D di-generate via GDScript (`scripts/HouseBuilder.gd`), tidak butuh file GLB eksternal.

Berisi:
- **Atap gabled** (atap segitiga) lengkap dengan shingles, ridge, dan **cerobong asap**.
- **Teras depan** dengan tangga marmer, pilar, dan dua **lampu kuning emisif** di samping pintu.
- **Jalan setapak** dari pagar ke pintu.
- **Pagar besi** mengelilingi halaman.
- **Pohon cemara** (multi-tier kerucut) di sekeliling rumah.
- **Interior**: ruang tamu (sofa, meja kopi, rak buku, piano), kamar tidur (ranjang + lemari), dapur, kamar mandi, hall + tangga ke basement.
- **Fireplace** marmer dengan kayu menyala (emisif + warm light).
- **Tiga chandelier** kristal dengan bola lampu emisif.
- **Lukisan berbingkai emas** di banyak dinding.
- **Basement** dengan peti-peti kayu (tempat sembunyi).
- **Spot sembunyi**: di bawah sofa / ranjang / meja, di dalam lemari, di belakang rak buku, peti di basement.

### Lighting & Environment (`scenes/GameWorld.tscn`)
- **Sun + Moon-fill** directional light (warna kebiruan untuk vibe malam).
- **Procedural sky** dengan warna malam.
- **WorldEnvironment**: SSAO, SSR, glow/bloom, fog volumetrik, tone mapping ACES, dan adjustment contrast/saturation untuk look cinematic.
- **ReflectionProbe** di dua titik dalam mansion untuk refleksi material metal/marble/glass.
- **OmniLight** kuning hangat di chandelier, lampu meja, dan teras.

## Kontrol
- `W A S D` — gerak
- `Spasi` — lompat
- `Shift` / `Ctrl` — sprint / crouch
- `E` atau klik kiri — interact (Seeker: tangkap; Hider: gunakan tempat sembunyi)
- `ESC` — keluar (pada layar Login)

## Struktur Folder

```
godot_hide_seek_realistic/
├── project.godot
├── icon.svg
├── assets/
│   ├── audio/                # WAV ambience, footstep, dll.
│   ├── shaders/              # menu_background.gdshader
│   └── theme/                # main_theme.tres (tema dark + gold)
├── scenes/
│   ├── Login.tscn            # Entry scene
│   ├── MainMenu.tscn
│   ├── CreateRoom.tscn       # Form pembuatan room
│   ├── JoinRoom.tscn
│   ├── Lobby.tscn
│   ├── GameWorld.tscn        # Mansion + lighting
│   ├── UI.tscn               # HUD in-game
│   ├── Player.tscn
│   └── NetworkManager.tscn   # Autoload
└── scripts/
    ├── Login.gd
    ├── MainMenu.gd
    ├── CreateRoom.gd
    ├── JoinRoom.gd
    ├── Lobby.gd
    ├── GameManager.gd
    ├── HouseBuilder.gd       # Procedural mansion generator
    ├── NetworkManager.gd
    ├── Player.gd
    ├── UIManager.gd
    └── VirtualJoystick.gd
```

## Catatan Teknis
- Min. Godot **4.3-stable**. Versi lebih lama tidak mendukung beberapa fitur Environment yang dipakai (mis. SSR di GL Compatibility renderer).
- Gunakan renderer **Forward Plus** (default `project.godot`) untuk SSAO + SSR. Mobile/Compatibility renderer akan menonaktifkan dua efek tsb. tetapi game tetap jalan.
- Saat host pertama kali, OS mungkin minta izin firewall — terima untuk membuka port `7777`.
